#include "Location.h"

Location::Location(string name, float loc_a, float loc_b,float trafik) {
    this->name = name;
    this->loc_a = loc_a;
    this->loc_b = loc_b;
    this->trafik=trafik;
}

ostream &operator<<(ostream &os, Location &location) {
    os << location.name << location.loc_a << location.loc_b << endl;
    return os;
}

string Location::get_name() {
    return  this->name;
}

pair<float,float> Location::get_loc() {
    pair<float,float> a;
    a.first=loc_a;
    a.second=loc_b;
    return a;

}

float Location::get_t(){
    return trafik;
}