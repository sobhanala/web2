#include "Driver.h"

Driver::Driver(string username) : User(username) {
    this->passenger = nullptr;
}

void Driver::set_passanger(Passenger *passenger) {
    this->passenger = passenger;
}

Passenger *Driver::get_passanger() {
    return this->passenger;
}
