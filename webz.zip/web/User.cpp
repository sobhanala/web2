#include "User.h"

User::User(string username) {
    this->username = username;
}

string User::get_username() {
    return this->username;
}
