#ifndef _USER_H
#define _USER_H

#include <string>

using namespace std;

class User {
public:
    User(string username);

    string get_username();

private:
    string username;
};


#endif 
