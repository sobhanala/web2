#include "MyServer.hpp"

MyServer::MyServer(int port) : Server(port) {}
