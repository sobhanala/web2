#include "Server_t.h"


const string SUCSSES="OK";

const string EROR_1="Bad Request";

const string DRIVER_ROLE="driver";

const string PASSENGER_ROLE="passenger";

const string NOT_FOUND_EROR="Not Found";

const string PER_EROR="Permission Denied";

const string SIGN_UP_COMMAND="signup";

const string TRIPS_COMMAND="trips";

const string FINISH_COMMAND="finish";

const string ACCEPT_COMMAND="accept";

const string COST_COMMAND="cost";

const int KM_RATIO=110.5;





Server_t::Server_t() {

}

Location *Server_t::find_location(string location) {
    for (auto &i: this->locations) {
        if (i.get_name() == location) {
            return &i;
        }
    }
    return nullptr;
}

string Server_t::calculate(string orgin,string destenation,string hury){
Location * orgin_p=find_location(orgin);
Location * destenation_p=find_location(destenation);
float retio;
if (hury=="yes")
{
  retio=1.2;
}
else{
  retio=1;
}
float first_num=(orgin_p->get_loc().first)-(destenation_p->get_loc().first);
float secend_num=(orgin_p->get_loc().second)-(destenation_p->get_loc().second);
float dist=KM_RATIO*sqrt(first_num*first_num+secend_num*secend_num);
float price=dist*retio*(orgin_p->get_t()+destenation_p->get_t())*10000;
stringstream stream;
stream << fixed << setprecision(2) << price;
string s = stream.str();
return s;

}

Response *Server_t::sign_up(Request *request) {
    string username, role;
     Response *res = new Response;

    try {
        username = request->getBodyParam("username");
        role = request->getBodyParam("role");
    } 
    catch (exception &e) {
        res=Response::redirect("/eror");
        return res;   

    }
    if (this->users.find(username) != this->users.end())
        res=Response::redirect("/erorfound");   
        return res;   

    if (role == DRIVER_ROLE) {
        this->signup(username, true);
        res=Response::redirect("/driver"); 
        return res;   

        }
    if (role == PASSENGER_ROLE) {
        this->signup(username,false);
        res=Response::redirect("/user");
        return res;

    }

    return res;
}

Response *Server_t::trips_post(Request *request) {
    string username, origin, destination,in_hurry;
    Response *res;
    try {
        username = request->getBodyParam("username");
        origin = request->getBodyParam("loc");
        destination = request->getBodyParam("des");
        in_hurry=request->getBodyParam("in_hurry");       
    } catch (exception &e) {
        res=Response::redirect("/eror");  
        return res;   
 
    }
    if (this->users.find(username) == this->users.end()){
         res=Response::redirect("/erorfound");
         return res;   
        }
    // if (this->find_location(origin) == nullptr)
    //     return new Response(NOT_FOUND_EROR);
    // if (this->find_location(destination) == nullptr)
    //     return new Response(NOT_FOUND_EROR);
    // if ( in_hurry!="yes"&&in_hurry!="no")
    //     return new Response(EROR_1); 
    
    Passenger *passenger;
    try {
        passenger = (Passenger *) this->users[username];
    } catch (exception &e) {
        res=Response::redirect("/erorfound");
        return res;   
    }
    if (passenger->get_trip() != nullptr){
        res=Response::redirect("/eror");   
         return res;   

    }
    int id = this->new_trip(passenger, find_location(origin), find_location(destination),calculate(origin,destination,in_hurry));
    return creat_res(id);
    
}

Response *  Server_t::creat_res(int id){
Response *res = new Response;
res->setHeader("Content-Type", "text/html");
string body;
body+="<!DOCTYPE HTML>";
body+="<html>";
body+="<head>";
body+="<link rel=stylesheet href=styles2.css>";
body+="<title>This is your trip</title>";
body+="</head>";
body+="<body>";
body+="<div class=add_info>";
body+="<a href=#default class=logo>S&S</a>";
body+="<div class=header-right>";
body+="<a class=active href=role.html>Home</a>";
body+="<a href=#contact>Contact</a>";
body+="<a href=#about>About</a>";
body+="<h1>this is your trip id:";
body+=to_string(id);
body+="</h1>";
body+="</div></form></body></html>";
res->setBody(body);
  return res;
}

vector<Trip *> Server_t::sort_t(vector<Trip *> trips){
    vector<Trip *>temp=trips;
  int i, j;
    for (i = 0; i < temp.size() - 1; i++){
        for (j = 0; j < temp.size() - i - 1; j++){
            if (temp[j]->get_cost() < temp[j + 1]->get_cost()){
                swap(temp[j], temp[j + 1]);
            }
}
}
    return temp;

}
 


Response *Server_t::accept(Request *request) {
    string username;
    int id;
    Response *res;
    try {
        username = request->getBodyParam("username");
        id = stoi(request->getBodyParam("id"));
    } 
    
    catch (exception &e) {
        res=Response::redirect("/eror");
        return res; 
    }
    
    if (this->users.find(username) == this->users.end()){
       res=Response::redirect("/erorfound");
        return res; 
        }
    Driver *driver;
    
    try {
        driver = (Driver *) this->users[username];
    } 
    
    catch (exception &e) {
       res=Response::redirect("/erorfound");
        return res; 
    }
    
    if (driver->get_passanger() != nullptr){
        res=Response::redirect("/eror");
        return res; 
        }

    for (auto trip: this->trips)
        if (trip->get_id() == id) {
            if (trip->get_state() != Trip::State::WAITING){
                finish(request);
                }
            
            this->accept_trip(trip, driver);
            res=Response::redirect("/driver");
            return res;
        }
    res=Response::redirect("/eror");
        return res; 
}

Response *Server_t::finish(Request *request) {
    string username;
    int id;
    Response *res;
    try {
        username = request->getBodyParam("username");
        id = stoi(request->getBodyParam("id"));
    } catch (exception &e) {
        res=Response::redirect("/eror");
        return res;
    }
    if (this->users.find(username) == this->users.end()){
        res=Response::redirect("/erorfound");
        return res;
    }
    Driver *driver;
    try {
        driver = (Driver *) this->users[username];
    } catch (exception &e) {
        res=Response::redirect("/erorfound");
        return res;
    }
    if (driver->get_passanger() == nullptr)
         res=Response::redirect("/eror");
         return res;
    if (driver->get_passanger()->get_trip()->get_id() != id){
        res=Response::redirect("/erorfound");
         return res;
        }

    finish_trip(driver->get_passanger()->get_trip());
   res=Response::redirect("/ok");
   return res;
}

// Response *Server_t::cost(Request *request){
// string username, origin, destination,in_hurry;    
// try {
//     username = request->getParam("username");
//     origin = request->getParam("origin");
//     destination = request->getParam("destination");
//     in_hurry=request->getParam("in_hurry");
//     }
//     catch (exception &e) {
//         return new Response(EROR_1);
//     }
//     if (this->users.find(username) == this->users.end())
//         return new Response(NOT_FOUND_EROR);
//     if (this->find_location(origin) == nullptr)
//         return new Response(NOT_FOUND_EROR);
//     if (this->find_location(destination) == nullptr)
//         return new Response(NOT_FOUND_EROR); 
    
//     return new Response(calculate(origin,destination,in_hurry));
    


// }

Response *Server_t::handle(Request *request) {
    if (request->getMethod() == Method::POST and request->getPath()== "/login") {
        return this->sign_up(request);
    }
    
    if (request->getMethod() == Method::POST and request->getPath() == "/user") {
        return this->trips_post(request);
    }
    
    if (request->getMethod() == Method::POST and request->getPath() == "/driver") {
        return this->accept(request);
    }
    
//     if (request->getMethod() == Request::Method::POST and request->getCommand() == ACCEPT_COMMAND) {
//         return this->accept(request);
//     }
    
//     if (request->getMethod() == Request::Method::POST and request->getCommand() == FINISH_COMMAND) {
//         return this->finish(request);
//     }
//     if (request->getMethod() == Request::Method::GET and request->getCommand() ==COST_COMMAND )
//     {
//         return this->cost(request);
//     }
    
//     return new Response(EROR_1);
// }
}

void Server_t::load_locations(vector<Location> locations) {
    this->locations = locations;
 }

void Server_t::signup(string &username, bool isDriver) {
    if (isDriver)
        this->users.emplace(username, new Driver(username));
    else
        this->users.emplace(username, new Passenger(username));

}

vector<Location> Server_t::get_location(){
    return locations;
}

int Server_t::new_trip(Passenger *passenger, Location *origin, Location *destination,string cost) {
    Trip *trip = new Trip(passenger, origin, destination,cost);
    passenger->set_trip(trip);
    this->trips.push_back(trip);
    return trip->get_id();
}

Server_t::~Server_t() {
    for (auto &user: this->users) {
        free(user.second);
    }
}

void Server_t::finish_trip(Trip *trip) {
    trip->set_state(Trip::State::FINISHED);
    trip->get_passanger()->set_trip(nullptr);
}

void Server_t::accept_trip(Trip *trip, Driver *driver) {
    trip->set_state(Trip::State::TRAVELING);
    driver->set_passanger(trip->get_passanger());
}
