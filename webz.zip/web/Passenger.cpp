#include "Passenger.h"

Passenger::Passenger(string username) : User(username) {
    this->trip = nullptr;
}

void Passenger::set_trip(Trip *trip) {
    this->trip = trip;
}

Trip *Passenger::get_trip() {
    return this->trip;
}
