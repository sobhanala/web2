#include "handlers.hpp"

using namespace std;

Response *travel_handler::callback(Request *req) {
  Response *res = new Response;
  res->setHeader("Content-Type", "text/html");
  string body;
body+="<!DOCTYPE HTML>";
body+="<html>";
body+="<head>";
body+="<link rel=stylesheet href=styles2.css>";
body+="<title>CHOOSE  YOUR TRIP</title>";
body+="</head>";
body+="<body>";
body+="<div class=add_info>";
body+="<a href=#default class=logo>S&S</a>";
body+="<div class=header-right>";
body+="<a class=active href=role.html>Home</a>";
body+="<a href=#contact>Contact</a>";
body+="<a href=#about>About</a>";
body+="</div>";
body+="</div>";
body+="<form action=/start>";
body+="<br>";
body+="<div class=headeralign=center>";
body+="<br><br><br>";
body+="<h1>choose your location ,have a nice trip</h1>";

body+="are you in hurry?";
body+="<br>";
body+="<input type=radio name=hurry value=Yes>Yes";
body+="<input type=radio name=hurry value=No>No";
body+="<br>";
body+="From<select name=loc >";
vector<Location> loc=back_server->get_location();
  for (int  i = 0; i < loc.size(); i++)
  {
    body+="<option";
    body+= "value=";
    body+=loc[i].get_name(); 
    body+=">";
    body+=loc[i].get_name();
  }
  body+="</select>";
  body+="to<select name= dis >";
    for (int  i = 0; i < loc.size(); i++)
  {
    body+="<option";
    body+= "value=";
    body+=loc[i].get_name(); 
    body+=">";
    body+=loc[i].get_name();
  }
  body+="</select>";
  body+="</select><br><br>";
body+="<input type=submit value=Submit trip method=post>";
body+="</div></form></body></html>";
res->setBody(body);
  return res;

}

Response *Login_handler::callback(Request *req) {
  return back_server->handle(req);
}
  
Response *show_trip_handler::callback(Request *req){
return back_server->handle(req);
}
Response * driver_handler::callback(Request *req){
 Response *res = new Response;
  res->setHeader("Content-Type", "text/html");
  string body;
 
 
 
 body+="<head>";


body+="<style>";
  body+="table.GeneratedTable {";
    body+="width: 100%;";
    body+="background-color: #ffffff;";
    body+="border-collapse: collapse;";
    body+="border-width: 2px;";
    body+="border-color: #ffcc00;";
    body+="border-style: solid;";
    body+="color: #000000;";
 body+=" }";

  body+="table.GeneratedTable td,";
  body+="table.GeneratedTable th {";
    body+="border-width: 2px;";
    body+="border-color: #ffcc00;";
    body+="border-style: solid;";
    body+="padding: 3px;";
  body+="}";

  body+="table.GeneratedTable thead {";
    body+="background-color: #ffcc00;";
  body+="}";

body+="</style>";
body+="</head>;";

body+="<body>";
body+="<input type=text name=username size=35 maxlength=35 placeholder=please enter your name >";
body+="<input type=text name=id size=35 maxlength=35 placeholder=wich id do you want??  >";
body+="<table class=GeneratedTable>";
  body+="<thead>";
    body+="<tr>";
      body+="<th>id</th>";
      body+="<th>loc</th>";
      body+="<th>des</th>";
      body+="<th>state</th>";
      body+="<th>price</th>";
      body+="<th>name</th>";
    body+="</tr>";
  body+="</thead>";
  body+="<tbody>";
    
   
    for (int i = 0; i <  back_server->trips.size(); i++)
    {
    body+="<tr>";
    body+="<td>";
    body+= to_string(back_server->trips[i]->get_id());
    body+="</td>";
    body+="</tr>";
    }


    for (int i = 0; i <  back_server->trips.size(); i++)
    {
    body+="<tr>";
    body+="<td>";
    body+= (back_server->trips[i]->get_loc_s()->get_name());
    body+="</td>";
    body+="</tr>";
    }
    for (int i = 0; i <  back_server->trips.size(); i++)
    {
    body+="<tr>";
    body+="<td>";
    body+= (back_server->trips[i]->get_loc_e()->get_name());
    body+="</td>";
    body+="</tr>";
    }
   for (int i = 0; i <  back_server->trips.size(); i++)
    {
      body+="<tr>";
    body+="<td>";
    if(back_server->trips[i]->get_state()==Trip::State::WAITING){
      body+="WAITING";
    }
    if(back_server->trips[i]->get_state()==Trip::State::TRAVELING){
      body+="TRAVELING";
    }
    if(back_server->trips[i]->get_state()==Trip::State::FINISHED){
      body+="FINISHED";
    }
      body+="</t= d>";
      body+="</tr>";
    }

    for (int i = 0; i <  back_server->trips.size(); i++)
    {
      body+="<tr>";
    body+="<td>";
    body+= back_server->trips[i]->get_cost();
      body+="</td>";
      body+="</tr>";
    }
    for (int i = 0; i <  back_server->trips.size(); i++)
    {
      body+="<tr>";
    body+="<td>";
    body+= back_server->trips[i]->get_passanger()->get_username();
      body+="</td>";
      body+="</tr>";
    }    
      
    
  body+="</tbody>";
body+="</table>";
body+="<input type=submit value=Submit trip method=post>";
body+="</body>";




}

Response *driver_post_handler::callback(Request *req){
return back_server->handle(req);
}