#include "handlers.hpp"
#include "MyServer.hpp"
#include "Location.h"
#include"Server_t.h"
#include <cstdlib> // for rand and srand
#include <ctime>   // for time
#include <iostream>
#include <fstream>

using namespace std;

vector<Location> read_locations(string path) {
    vector<Location> locations;
    ifstream file(path);
    string h1, h2, h3,h4;
    getline(file, h1, ',');
    getline(file, h2, ',');
    getline(file, h3,',');
    getline(file,h4);
    string c1, c2, c3,c4;
    while (getline(file, c1, ',')) {
        getline(file, c2, ',');
        getline(file, c3,',');
        getline(file, c4);
        string location;
        double latitude, longitude;
        double trafik;
        if (h1 == "location") {
            location = c1;
            if (h2 == "latitude" and h3=="longitude") {
                latitude = stod(c2);
                longitude = stod(c3);
                trafik=stod(c4);
            } 

        locations.emplace_back(location, latitude, longitude,trafik);
    }
    }
    return locations;

}

int main(int argc, char **argv) {
  srand(time(NULL));
  Server_t back_server;
  back_server.load_locations(read_locations(argv[1]));
  try {
    MyServer server(5000);
    server.setNotFoundErrPage("static/404.html");
    server.get("/login", new ShowPage("staticks/role.html"));
    server.post("/login",new Login_handler());
    server.get("/user",new travel_handler());
    server.post("/user",new show_trip_handler());
    server.get("/eror",new ShowPage("staticks/badrequest.html"));
    server.get("/erorfound",new ShowPage("staticks/notfound.html"));
    server.get("/ok",new ShowPage("staticks/ok.html"));
    server.get("/driver",new driver_handler());
    server.post("/driver",new driver_post_handler());
    server.run();
    }
    catch (Server::Exception e) {
    cerr << e.getMessage() << endl;
  }
    }