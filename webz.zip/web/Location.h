#ifndef _LOCATION_H
#define _LOCATION_H

#include <string>
#include <iostream>

using namespace std;

class Location {
public:
    Location(string name, float loc_a, float loc_b,float trafik);

    friend ostream &operator<<(ostream &os, Location &location);

    string get_name();

    pair<float,float> get_loc();

    float get_t();

private:
    string name;
    float loc_b;
    float loc_a;
    float trafik;
};


#endif 
