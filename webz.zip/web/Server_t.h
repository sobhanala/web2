#ifndef _Server_t_H
#define _Server_t_H

#include <vector>
#include "utils/request.hpp"
#include "utils/response.hpp"
#include "User.h"
#include "Driver.h"
#include <stdlib.h>
#include "server/server.hpp"
#include <cstdlib> // for rand and srand
#include <ctime>   // for time
#include "Driver.h"
#include "Passenger.h"
#include"Location.h"
#include <iostream>
#include <sstream>
#include <cmath>
#include <iomanip>
#include <string> 

class Server_t {
public:
    Server_t();

    ~Server_t();

    Response *handle(Request *request);

    void load_locations(vector<Location> locations);

    vector<Location> get_location();
    vector<Trip *> trips;


private:
    vector<Location> locations;
    map<string, User *> users;
    
    Response *  creat_res(int id);

    void signup(string &username, bool isDriver);

    int new_trip(Passenger *passenger, Location *origin, Location *destination,string cost);

    void accept_trip(Trip *trip, Driver *driver);

    void finish_trip(Trip *trip);

    Response *sign_up(Request *request);

    Response *trips_post(Request *request);

    Response *trips_get(Request *request);

    Response *trips_delete(Request *request);

    Response *accept(Request *request);

    Response *finish(Request *request);
    
    Response * cost(Request *request);

    Location *find_location(string location);
    
    string calculate(string orgin,string destenation,string hury);

    vector<Trip *> sort_t(vector<Trip *> trips);
};


#endif 
