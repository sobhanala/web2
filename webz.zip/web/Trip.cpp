#include "Trip.h"

const string WAITING="waiting";
const string TRAVEL="traveling";
const string FINISH="finished";



int Trip::next_id = 1;

Trip::Trip(Passenger *passenger, Location *start, Location *destination,string cost) {
    this->passenger = passenger;
    this->start = start;
    this->destination = destination;
    this->id = next_id;
    this->cost=cost;
    this->state = State::WAITING;
    Trip::next_id++;
}

int Trip::get_id() {
    return this->id;
}

Location * Trip::get_loc_s(){
    return start;
}
Location * Trip::get_loc_e(){
    return destination;
}

ostream &operator<<(ostream &os, Trip &trip) {
    os << trip.get_id() <<" "<< trip.passenger->get_username() << " " << trip.start->get_name() << " "<< trip.destination->get_name()<<" "<<trip.cost<<" ";
    switch (trip.state) {
        case Trip::State::WAITING:
            os << WAITING;
            break;
        case Trip::State::TRAVELING:
            os << TRAVEL;
            break;
        case Trip::State::FINISHED:
            os << FINISH;
            break;
    }
    return os;
}
//this part is for cleaning in cout

Trip::State Trip::get_state() {
    return this->state;
}

void Trip::set_state(Trip::State state) {
    this->state = state;
}

Passenger *Trip::get_passanger() {
    return this->passenger;
}

float Trip::get_cost(){
    return stof(cost);
}