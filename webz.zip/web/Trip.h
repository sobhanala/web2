#ifndef _TRIP_H
#define _TRIP_H

#include <string>
#include "Passenger.h"
#include "Location.h"
#include <ostream>

using namespace std;

class Passenger;

class Trip {
public:
    enum class State {
        WAITING, TRAVELING, FINISHED
    };

    Trip(Passenger *passenger, Location *start, Location *destination,string cost);

    int get_id();

    State get_state();

    void set_state(State state);
    float get_cost();
    Passenger *get_passanger();
    Location * get_loc_s();
    Location * get_loc_e();


    friend ostream &operator<<(ostream &os, Trip &trip);

private:
    static int next_id;
    Passenger *passenger;
    Location *start;
    Location *destination;
    State state;
    int id;
    string cost;
};


#endif 
