#ifndef _DRIVER_H
#define _DRIVER_H

#include "User.h"
#include "Passenger.h"

class Driver : public User {
public:
    Driver(string username);

    void set_passanger(Passenger *passenger);

    Passenger *get_passanger();

private:
    Passenger* passenger;
};


#endif 
