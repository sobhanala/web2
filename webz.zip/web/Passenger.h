#ifndef _PASSENGER_H
#define _PASSENGER_H


#include "User.h"
#include "Trip.h"

class Trip;
class Passenger : public User {
public:
    Passenger(string username);
    Trip *get_trip();
    void set_trip(Trip *trip);
private:
    Trip *trip;
};


#endif 
